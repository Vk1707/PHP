<?php


Route::get('/', function () {
    return view('welcome');
});


Route::get('addproduct', 'ProductController@AddProduct');
Route::post('addproduct', 'ProductController@AddProduct');
Route::get('displayproducts', 'ProductController@DisplayProducts');
Route::get('deleteproduct/{id}','ProductController@DeleteProduct');
Route::get('updateproduct/{id}', 'ProductController@UpdateProduct');
Route::post('updateproduct/{id}', 'ProductController@UpdateProduct');



Route::get('uploadprofile', 'ProfileController@UploadProfile');
Route::post('uploadprofile', 'ProfileController@UploadProfile');
Route::get('displayprofiles', 'ProfileController@DisplayProfiles');
Route::get('uploadprofiles', 'ProfileController@UploadProfiles');
Route::post('uploadprofiles', 'ProfileController@UploadProfiles');



Route::get('cookiehome','CookieController@CookieHome');
Route::get('cookieabout','CookieController@CookieAbout');
Route::get('cookieaccount','CookieController@CookieAccount');
Route::get('cookielogin','CookieController@CookieLogin');
Route::post('cookielogin','CookieController@CookieLogin');
Route::get('cookielogout','CookieController@CookieLogout');

//API EndPoints
Route::post('rest/product/add', 'RestController@AddProduct');
Route::get('rest/products', 'RestController@GetProducts');
Route::get('rest/product/{id}', 'RestController@GetProduct');
Route::delete('rest/product/delete/{id}', 'RestController@DeleteProduct');
Route::put('rest/product/update/{id}', 'RestController@UpdateProduct');



//Mail URL
Route::get('congratulation', 'MailController@Congratulation');