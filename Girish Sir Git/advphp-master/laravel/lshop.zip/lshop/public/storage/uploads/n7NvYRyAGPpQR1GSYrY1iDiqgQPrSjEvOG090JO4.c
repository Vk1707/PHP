C++ Programming Language

C++ is an object oriented programming language which derives its syntax from C language. C++ can also be considered as an extension to the C Programming language. C++ programming language relies on the same base libraries as C, which means both C and C++ programming languages can use the same header/library files to perform the operations.

Difference Between C and C++ Programming language

1. Stream

C++ uses separate streams for read and write operations.

#include<iostream.h>


cin>>a;			//Reads a value from the console
cout<<a;		//Writes a value on the console.


2. Variable Declaration

Unlike C language, variables can be declare anywhere in the program.

e.g.

for(int i=0;i<5;i++)
{
	
}



3. Function Overloading (Polymorphism)

In C++ a function can be defined more than once.

e.g.

void Sum(int ,int )
{
	...
}

void Sum(float, float)
{
	...
}


4. Namespaces

Namespaces allows you to logically group a set of classes or functions.

namespace Buyer;

class Register
{
	..
}


namespace Seller

class Register
{
	..
}


5. Coupling between data fields and member functions

struct Book
{
	int bookno;
	char name[20];

	void Set()
	{

	}

	void Sale()
	{

	}
}

6. Operator Overloading

In C++ operators can be overloaded to operator with non primitive type elements as well.


7. Inheritance

8. Method Overriding

9. Templates

10. Exception Handling

11. Enhanced Files Library.






C++ Program Skeleton

#include<...>

void main()
{
	
}



C++ Operators

1. Arithmetic (+,/,-,*,%)
2. Relational (>,<,>=,<=,==,!=)
3. Logical (&&,||,!)
4. Assignment (=,+=,/=,-=,*=,%=)
5. Conditional (?:)
6. Special (, ,&,*,->,.,sizeof)


Data Types

Primitive
	int
	char
	float
	double
	void
Non Primitive
	Class
	Struct
	Enum
	Unions


Input and Output (iostream.h)

Output Statement

cout<<value;			// << : Output Redirection Operator



e.g.

cout<<"Hello World";


Cascading Function Calls

cout<<"Hello World"<<a<<"Hello";


Input Statement

cin>>variable;

e.g.

cin>>a;				// >> : Input redirection operator


cin>>a>>b>>c;



