<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="addproduct/">Add New Product</a>

	<h1>Product Details</h1>
	<table border="1">
		<tr>
			<td>Id</td>
			<td>Name</td>
			<td>Category</td>
			<td>Brand</td>
			<td>Quantity</td>
			<td>Price</td>
			<td>Command</td>
		</tr>
		<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($product->id); ?></td>
			<td><?php echo e($product->name); ?></td>
			<td><?php echo e($product->category); ?></td>
			<td><?php echo e($product->brand); ?></td>
			<td><?php echo e($product->qty); ?></td>
			<td><?php echo e($product->price); ?></td>
			<td>
				<a href="deleteproduct/<?php echo e($product->id); ?>">Delete</a> |
				<a href="updateproduct/<?php echo e($product->id); ?>">Update</a>
			</td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</body>
</html>


<?php /**PATH C:\xampp\htdocs\lshop\resources\views/displayproducts.blade.php ENDPATH**/ ?>