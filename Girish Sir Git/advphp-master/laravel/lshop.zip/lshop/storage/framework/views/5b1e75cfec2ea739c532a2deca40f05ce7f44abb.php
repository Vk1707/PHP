<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Add New Product</h1>
	<form method="post">
	<?php echo csrf_field(); ?>
	<table>
		<tr>
			<td>Name</td>
			<td><input type="text" name="name" value="<?php echo e($product->name); ?>"></td>
		</tr>
		<tr>
			<td>Category</td>
			<td><input type="text" name="category" value="<?php echo e($product->category); ?>"></td>
		</tr>
		<tr>
			<td>Brand</td>
			<td><input type="text" name="brand" value="<?php echo e($product->brand); ?>"></td>
		</tr>
		<tr>
			<td>Quantity</td>
			<td><input type="text" name="qty" value="<?php echo e($product->qty); ?>"></td>
		</tr>
		<tr>
			<td>Price</td>
			<td><input type="text" name="price" value="<?php echo e($product->price); ?>"></td>
		</tr>
		<tr>
			<td colspan="2">
				<input type="submit" value="Add Product">
			</td>
		</tr>
	</table>
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\lshop\resources\views/updateproduct.blade.php ENDPATH**/ ?>