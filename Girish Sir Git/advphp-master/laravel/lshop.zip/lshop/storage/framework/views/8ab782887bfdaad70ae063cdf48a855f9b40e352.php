<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post">
		<?php echo csrf_field(); ?>
		<input type="text" name="userid">
		<input type="text" name="password">
		<input type="submit" value="Login">
	</form>
</body>
</html><?php /**PATH C:\xampp\htdocs\lshop\resources\views/cookielogin.blade.php ENDPATH**/ ?>