<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Congratulations Your Account has been created successfully</h1>

	<p>
		This mail has been generated using Laravel Mail facade.
	</p>
</body>
</html><?php /**PATH C:\xampp\htdocs\lshop\resources\views/mails/congratulations.blade.php ENDPATH**/ ?>