<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div>
	<a href="cookiehome">Home</a>
	<a href="cookieaccount">Account</a>
	<a href="cookieabout">About</a>
	</div>

	<div>
		<?php if($userid==""): ?>
		<a href="cookielogin">Login</a>
		<a href="#">Register</a>
		<?php else: ?>
		<a href="#">Welcome <?php echo e($userid); ?></a>
		<a href="cookielogout">Logout</a>
		<?php endif; ?>
	</div>


	<?php $__env->startSection('content'); ?>
	<?php echo $__env->yieldSection(); ?>

	<footer>
	</footer>

</body>
</html><?php /**PATH C:\xampp\htdocs\lshop\resources\views/cookiebase.blade.php ENDPATH**/ ?>