<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="uploadprofile">Add New Profile</a>
	<h3>Profiles</h3>
	<table border="1">
		<tr>
			<td>Id</td>
			<td>Name</td>
			<td>Photo</td>
			<td>Command</td>
		</tr>
		<?php $__currentLoopData = $profiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $profile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		<tr>
			<td><?php echo e($profile->id); ?></td>
			<td><?php echo e($profile->name); ?></td>
			<td><img src="storage/<?php echo e($profile->photo); ?>" height="100px" width="100px"></td>
			<td></td>
		</tr>
		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
	</table>
</body>
</html>



<?php /**PATH C:\xampp\htdocs\lshop\resources\views/displayprofiles.blade.php ENDPATH**/ ?>