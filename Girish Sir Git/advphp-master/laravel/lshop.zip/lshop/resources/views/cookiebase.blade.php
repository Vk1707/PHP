<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<div>
	<a href="cookiehome">Home</a>
	<a href="cookieaccount">Account</a>
	<a href="cookieabout">About</a>
	</div>

	<div>
		@if($userid=="")
		<a href="cookielogin">Login</a>
		<a href="#">Register</a>
		@else
		<a href="#">Welcome {{$userid}}</a>
		<a href="cookielogout">Logout</a>
		@endif
	</div>


	@section('content')
	@show

	<footer>
	</footer>

</body>
</html>