<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<form method="post">
		@csrf
		<input type="text" name="userid">
		<input type="text" name="password">
		<input type="submit" value="Login">
	</form>
</body>
</html>