<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="addproduct/">Add New Product</a>

	<h1>Product Details</h1>
	<table border="1">
		<tr>
			<td>Id</td>
			<td>Name</td>
			<td>Category</td>
			<td>Brand</td>
			<td>Quantity</td>
			<td>Price</td>
			<td>Command</td>
		</tr>
		@foreach($products as $product)
		<tr>
			<td>{{$product->id}}</td>
			<td>{{$product->name}}</td>
			<td>{{$product->category}}</td>
			<td>{{$product->brand}}</td>
			<td>{{$product->qty}}</td>
			<td>{{$product->price}}</td>
			<td>
				<a href="deleteproduct/{{$product->id}}">Delete</a> |
				<a href="updateproduct/{{$product->id}}">Update</a>
			</td>
		</tr>
		@endforeach
	</table>
</body>
</html>


