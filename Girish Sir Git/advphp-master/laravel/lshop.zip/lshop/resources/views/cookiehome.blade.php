@extends('cookiebase')


@section('content')
<h1>Home</h1>
@endsection