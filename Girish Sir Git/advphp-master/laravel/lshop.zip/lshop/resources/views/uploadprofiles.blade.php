<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Create Profile</h1>
	<form method="post" enctype="multipart/form-data">
		@csrf
		<table>
			<tr>
				<td>Name</td>
				<td><input type="text" name="name"></td>
			</tr>
			<tr>
				<td>Photo</td>
				<td><input type="file" multiple name="photo[]"></td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" value="Upload"></td>
			</tr>
		</table>
	</form>
</body>
</html>