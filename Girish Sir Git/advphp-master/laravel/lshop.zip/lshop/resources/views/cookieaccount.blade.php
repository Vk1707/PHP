@extends('cookiebase')


@section('content')
<h1>Account</h1>
@endsection