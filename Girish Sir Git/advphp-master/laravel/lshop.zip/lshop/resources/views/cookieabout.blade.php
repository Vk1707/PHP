@extends('cookiebase')


@section('content')
<h1>About</h1>
@endsection