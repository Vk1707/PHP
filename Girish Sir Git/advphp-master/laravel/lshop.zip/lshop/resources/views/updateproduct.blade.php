<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<h1>Add New Product</h1>
	<form method="post">
	@csrf
	<table>
		<tr>
			<td>Name</td>
			<td><input type="text" name="name" value="{{$product->name}}"></td>
		</tr>
		<tr>
			<td>Category</td>
			<td><input type="text" name="category" value="{{$product->category}}"></td>
		</tr>
		<tr>
			<td>Brand</td>
			<td><input type="text" name="brand" value="{{$product->brand}}"></td>
		</tr>
		<tr>
			<td>Quantity</td>
			<td><input type="text" name="qty" value="{{$product->qty}}"></td>
		</tr>
		<tr>
			<td>Price</td>
			<td><input type="text" name="price" value="{{$product->price}}"></td>
		</tr>
		<tr>
			<td colspan="2">
				<input type="submit" value="Add Product">
			</td>
		</tr>
	</table>
	</form>
</body>
</html>