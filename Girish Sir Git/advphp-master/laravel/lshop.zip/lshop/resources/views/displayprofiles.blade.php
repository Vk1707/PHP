<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
	<a href="uploadprofile">Add New Profile</a>
	<h3>Profiles</h3>
	<table border="1">
		<tr>
			<td>Id</td>
			<td>Name</td>
			<td>Photo</td>
			<td>Command</td>
		</tr>
		@foreach($profiles as $profile)
		<tr>
			<td>{{$profile->id}}</td>
			<td>{{$profile->name}}</td>
			<td><img src="storage/{{$profile->photo}}" height="100px" width="100px"></td>
			<td></td>
		</tr>
		@endforeach
	</table>
</body>
</html>



