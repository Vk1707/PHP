<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class InitialSchema extends Migration
{
    public function up()
    {
        Schema::create('Product',function(Blueprint $table){

            $table->bigIncrements('id');
            $table->string('name',40);
            $table->string('category',40);
            $table->string('brand',40);
            $table->integer('qty');
            $table->decimal('price',10,2);
            $table->timestamps();
            
        });
    }

    public function down()
    {
    }
}
