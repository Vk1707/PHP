<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;

class CongratulationMail extends Mailable
{
    use Queueable, SerializesModels;

    public function __construct()
    {
    }

    public function build()
    {
        return $this->from('niecspi@gmail.com')
                    ->view('mails/congratulations')
                    ->attach('storage/uploads/6o1nCQ82kt2XJnaY65GYjOxEcNKWAIAe2t7pfecj.jpeg', ['as' => 'product.jpg','mime' => 'image/jpeg',]);
    }
}
