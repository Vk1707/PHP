<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use Illuminate\Support\Facades\Mail;

use App\Mail\CongratulationMail;

class MailController extends Controller
{
    public function Congratulation(Request $request)
    {
    	Mail::to('trainer.gkattri@gmail.com')->send(new CongratulationMail());

    	echo "Mail Sent";
    }
}
