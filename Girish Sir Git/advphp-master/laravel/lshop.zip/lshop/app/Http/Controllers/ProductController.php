<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Product;


class ProductController extends Controller
{
    public function AddProduct(Request $request)
    {
    	if($request->method()=='GET'){
    		return view('addproduct');
    	}
    	else{
    		$product = new Product();
    		$product->name=$request->POST('name');
    		$product->category=$request->POST('category');
    		$product->price=$request->POST('price');
    		$product->brand=$request->POST('brand');
    		$product->qty=$request->POST('qty');
    		$product->save();
    		return redirect('displayproducts/');
    	}
    }

    public function DisplayProducts()
    {
    	$products=Product::all();
    	return view('displayproducts',['products'=>$products]);
    }

    public function DeleteProduct(Request $request, $id)
    {
    	Product::find($id)->delete();
   		return redirect('displayproducts/');
    }

    public function UpdateProduct(Request $request, $id)
    {
    	$product=Product::find($id);

    	if($request->method()=='GET'){
    		return view('updateproduct',['product'=>$product]);
    	}
    	else{
    		$product->name=$request->POST('name');
    		$product->category=$request->POST('category');
    		$product->price=$request->POST('price');
    		$product->brand=$request->POST('brand');
    		$product->qty=$request->POST('qty');
    		$product->update();    		
	   		return redirect('displayproducts/');
    	}
    }
}
