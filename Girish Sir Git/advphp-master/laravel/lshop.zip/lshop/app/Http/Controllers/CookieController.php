<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CookieController extends Controller
{
   	public function CookieHome(Request $request){

   		$userid="";   		
   		if($request->cookie('userid')!==null)
   		{
   			$userid=$request->cookie('userid');
   		}

   		return view('cookiehome',['userid'=>$userid]);
   	}

   	public function CookieAbout(Request $request){
   		$userid="";   		
   		if($request->cookie('userid')!==null)
   		{
   			$userid=$request->cookie('userid');
   		}

   		return view('cookieabout',['userid'=>$userid]);
   	}

   	public function CookieAccount(Request $request){
   		$userid="";   		
   		if($request->cookie('userid')!==null)
   		{
   			$userid=$request->cookie('userid');
   		}
   		else{
   			return redirect('cookielogin');
   		}

   		return view('cookieaccount',['userid'=>$userid]);
   	}

   	public function CookieLogin(Request $request){
   		if($request->method()=='GET')
   		{
   			return view('cookielogin');
   		}
   		else
   		{
   			$response=redirect('cookiehome');
   			$response->cookie('userid',$request->POST('userid'),60*24);
   			return $response;
   		}
   	}

   	public function CookieLogout(Request $request){
   		$response=redirect('cookiehome');
   		$response->cookie('userid','',-60);
   		return $response;
   	}


}
