<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;
use App\Profile;

class ProfileController extends Controller
{
    public function UploadProfile(Request $request)
    {
    	if($request->method()=="GET"){
    		return view('uploadprofile');
    	}
    	else{
    		//extract($request->all());

    		$photourl = $request->file('photo')->store('uploads','public');
    		$name=$request->POST('name');

    		$profile=new Profile();
    		$profile->name=$name;
    		$profile->photo=$photourl;
    		$profile->save();

    		return redirect('displayprofiles');
    	}
    }


    public function UploadProfiles(Request $request)
    {
    	if($request->method()=="GET"){
    		return view('uploadprofiles');
    	}
    	else{

    		$name=$request->POST('name');
    		$files=$request->file('photo');

    		foreach($files as $file){
    			$photourl=$file->store('uploads','public');
    			$profile=new Profile();
    			$profile->name=$name;
    			$profile->photo=$photourl;
    			$profile->save();
    		}

    		return redirect('displayprofiles');
    	}
    }



    public function DisplayProfiles()
    {
    	$profiles=Profile::all();
    	return view('displayprofiles',['profiles'=>$profiles]);
    }
}
