<?php

namespace App\Http\Controllers;
use Illuminate\Http\Request;

use App\Product;

class RestController extends Controller
{
    function AddProduct(Request $request){
    	$product=new Product();    
    	$product->create($request->all());
    	return "Record Saved";
    }

    function GetProducts(Request $request){
    	$products=Product::all();
    	return $products;
    }

    function GetProduct(Request $request, $id){
    	$products=Product::find($id);
    	return $products;
    }

    function DeleteProduct(Request $request, $id){
    	$product=Product::find($id);
    	$product->delete();
   		return "Record Deleted";
    }

    function UpdateProduct(Request $request, $id){
		$product=Product::find($id);		
		$product->update($request->all());
		return "Record Updated";    		
	}
}
